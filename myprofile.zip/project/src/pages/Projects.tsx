import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ExternalLink, Github, Eye, Filter } from 'lucide-react';

const Projects: React.FC = () => {
  const [activeFilter, setActiveFilter] = useState('all');

  const projects = [
    {
      id: 1,
      title: 'E-Commerce Platform',
      description: 'Full-stack e-commerce solution with React, Node.js, and Stripe integration',
      image: 'https://images.pexels.com/photos/230544/pexels-photo-230544.jpeg?auto=compress&cs=tinysrgb&w=600',
      tech: ['React', 'Node.js', 'MongoDB', 'Stripe'],
      category: 'fullstack',
      githubUrl: '#',
      liveUrl: '#',
      featured: true,
    },
    {
      id: 2,
      title: 'AI Dashboard',
      description: 'Modern dashboard with AI-powered analytics and real-time data visualization',
      image: 'https://images.pexels.com/photos/265087/pexels-photo-265087.jpeg?auto=compress&cs=tinysrgb&w=600',
      tech: ['React', 'Python', 'TensorFlow', 'D3.js'],
      category: 'frontend',
      githubUrl: '#',
      liveUrl: '#',
      featured: true,
    },
    {
      id: 3,
      title: 'Task Management App',
      description: 'Collaborative task management with real-time updates and team features',
      image: 'https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=600',
      tech: ['Vue.js', 'Firebase', 'Vuetify'],
      category: 'frontend',
      githubUrl: '#',
      liveUrl: '#',
      featured: false,
    },
    {
      id: 4,
      title: 'Weather App',
      description: 'Beautiful weather application with location-based forecasts',
      image: 'https://images.pexels.com/photos/1118873/pexels-photo-1118873.jpeg?auto=compress&cs=tinysrgb&w=600',
      tech: ['React Native', 'OpenWeather API'],
      category: 'mobile',
      githubUrl: '#',
      liveUrl: '#',
      featured: false,
    },
    {
      id: 5,
      title: 'Portfolio Website',
      description: 'Responsive portfolio with modern animations and interactive elements',
      image: 'https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=600',
      tech: ['React', 'Framer Motion', 'Tailwind'],
      category: 'frontend',
      githubUrl: '#',
      liveUrl: '#',
      featured: false,
    },
    {
      id: 6,
      title: 'Social Media API',
      description: 'RESTful API for social media platform with authentication and media upload',
      image: 'https://images.pexels.com/photos/267350/pexels-photo-267350.jpeg?auto=compress&cs=tinysrgb&w=600',
      tech: ['Node.js', 'Express', 'PostgreSQL'],
      category: 'backend',
      githubUrl: '#',
      liveUrl: '#',
      featured: false,
    },
    {
      id: 7,
      title: 'Fitness Tracker',
      description: 'Mobile app for tracking workouts and fitness goals with data visualization',
      image: 'https://images.pexels.com/photos/841130/pexels-photo-841130.jpeg?auto=compress&cs=tinysrgb&w=600',
      tech: ['Flutter', 'Firebase', 'Chart.js'],
      category: 'mobile',
      githubUrl: '#',
      liveUrl: '#',
      featured: false,
    },
    {
      id: 8,
      title: 'Real Estate Platform',
      description: 'Property listing platform with search, filters, and virtual tours',
      image: 'https://images.pexels.com/photos/186077/pexels-photo-186077.jpeg?auto=compress&cs=tinysrgb&w=600',
      tech: ['Next.js', 'Prisma', 'PostgreSQL'],
      category: 'fullstack',
      githubUrl: '#',
      liveUrl: '#',
      featured: false,
    },
    {
      id: 9,
      title: 'Blog CMS',
      description: 'Content management system with markdown editor and SEO optimization',
      image: 'https://images.pexels.com/photos/590016/pexels-photo-590016.jpeg?auto=compress&cs=tinysrgb&w=600',
      tech: ['React', 'Gatsby', 'GraphQL'],
      category: 'fullstack',
      githubUrl: '#',
      liveUrl: '#',
      featured: false,
    },
    {
      id: 10,
      title: 'Crypto Tracker',
      description: 'Cryptocurrency tracking app with real-time prices and portfolio management',
      image: 'https://images.pexels.com/photos/844124/pexels-photo-844124.jpeg?auto=compress&cs=tinysrgb&w=600',
      tech: ['React', 'CoinGecko API', 'Chart.js'],
      category: 'frontend',
      githubUrl: '#',
      liveUrl: '#',
      featured: false,
    },
  ];

  const categories = [
    { id: 'all', label: 'All Projects' },
    { id: 'fullstack', label: 'Full Stack' },
    { id: 'frontend', label: 'Frontend' },
    { id: 'backend', label: 'Backend' },
    { id: 'mobile', label: 'Mobile' },
  ];

  const filteredProjects = activeFilter === 'all' 
    ? projects 
    : projects.filter(project => project.category === activeFilter);

  const featuredProjects = projects.filter(project => project.featured);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen pt-20 pb-10 relative z-10"
    >
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl md:text-6xl font-bold heading-glow mb-4">
            My <span className="text-neon-blue">Projects</span>
          </h1>
          <p className="text-xl text-cyber-muted max-w-2xl mx-auto">
            A showcase of innovative solutions and creative implementations
          </p>
        </motion.div>

        {/* Featured Projects */}
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="mb-16"
        >
          <h2 className="text-2xl font-bold text-neon-green mb-8 flex items-center">
            <Eye className="w-6 h-6 mr-2" />
            Featured Projects
          </h2>
          <div className="grid md:grid-cols-2 gap-8">
            {featuredProjects.map((project, index) => (
              <motion.div
                key={project.id}
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.6 + index * 0.1 }}
                className="card-glow rounded-2xl overflow-hidden group"
              >
                <div className="relative overflow-hidden">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-48 object-cover transition-transform duration-300 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-cyber-bg via-transparent to-transparent opacity-60" />
                  <div className="absolute top-4 right-4 bg-neon-blue/20 backdrop-blur-sm rounded-full px-3 py-1">
                    <span className="text-xs font-semibold text-neon-blue">Featured</span>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-cyber-text mb-2">{project.title}</h3>
                  <p className="text-cyber-muted mb-4">{project.description}</p>
                  
                  <div className="flex flex-wrap gap-2 mb-4">
                    {project.tech.map((tech, techIndex) => (
                      <span
                        key={techIndex}
                        className="px-3 py-1 text-xs bg-cyber-border text-neon-blue rounded-full"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>

                  <div className="flex space-x-4">
                    <a
                      href={project.githubUrl}
                      className="flex items-center space-x-2 text-cyber-muted hover:text-neon-blue transition-colors"
                    >
                      <Github className="w-4 h-4" />
                      <span className="text-sm">Code</span>
                    </a>
                    <a
                      href={project.liveUrl}
                      className="flex items-center space-x-2 text-cyber-muted hover:text-neon-green transition-colors"
                    >
                      <ExternalLink className="w-4 h-4" />
                      <span className="text-sm">Live Demo</span>
                    </a>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Filter Buttons */}
        <motion.div
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="flex items-center justify-center mb-12"
        >
          <div className="flex items-center space-x-4 bg-cyber-card/50 backdrop-blur-sm rounded-2xl p-2">
            <Filter className="w-5 h-5 text-neon-blue ml-2" />
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setActiveFilter(category.id)}
                className={`px-6 py-2 rounded-xl transition-all duration-300 ${
                  activeFilter === category.id
                    ? 'bg-neon-blue text-cyber-bg font-semibold'
                    : 'text-cyber-text hover:text-neon-blue hover:bg-cyber-border/20'
                }`}
              >
                {category.label}
              </button>
            ))}
          </div>
        </motion.div>

        {/* All Projects Grid */}
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 1 }}
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {filteredProjects.map((project, index) => (
            <motion.div
              key={project.id}
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 1.2 + index * 0.1 }}
              className="card-glow rounded-2xl overflow-hidden group hover:scale-105 transition-transform duration-300"
            >
              <div className="relative overflow-hidden">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-48 object-cover transition-transform duration-300 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-cyber-bg via-transparent to-transparent opacity-60" />
              </div>
              <div className="p-6">
                <h3 className="text-lg font-bold text-cyber-text mb-2">{project.title}</h3>
                <p className="text-cyber-muted text-sm mb-4">{project.description}</p>
                
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.tech.slice(0, 3).map((tech, techIndex) => (
                    <span
                      key={techIndex}
                      className="px-2 py-1 text-xs bg-cyber-border text-neon-blue rounded-full"
                    >
                      {tech}
                    </span>
                  ))}
                  {project.tech.length > 3 && (
                    <span className="px-2 py-1 text-xs bg-cyber-border text-cyber-muted rounded-full">
                      +{project.tech.length - 3} more
                    </span>
                  )}
                </div>

                <div className="flex space-x-4">
                  <a
                    href={project.githubUrl}
                    className="flex items-center space-x-2 text-cyber-muted hover:text-neon-blue transition-colors text-sm"
                  >
                    <Github className="w-4 h-4" />
                    <span>Code</span>
                  </a>
                  <a
                    href={project.liveUrl}
                    className="flex items-center space-x-2 text-cyber-muted hover:text-neon-green transition-colors text-sm"
                  >
                    <ExternalLink className="w-4 h-4" />
                    <span>Demo</span>
                  </a>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* CTA Section */}
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 1.5 }}
          className="mt-16 text-center"
        >
          <div className="card-glow p-8 rounded-2xl">
            <h3 className="text-2xl font-bold text-neon-blue mb-4">Interested in Working Together?</h3>
            <p className="text-cyber-muted mb-6">
              Let's discuss your next project and bring your ideas to life
            </p>
            <button className="neon-btn">
              Get In Touch
            </button>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
};

export default Projects;