import React from 'react';
import { motion } from 'framer-motion';
import { User, MapPin, Calendar, Heart, Zap, Target } from 'lucide-react';

const About: React.FC = () => {
  const stats = [
    { label: 'Years of Experience', value: '5+', color: 'text-neon-blue' },
    { label: 'Projects Completed', value: '50+', color: 'text-neon-green' },
    { label: 'Happy Clients', value: '30+', color: 'text-neon-pink' },
    { label: 'Code Commits', value: '1000+', color: 'text-neon-purple' },
  ];

  const interests = [
    { icon: Zap, label: 'Innovation', description: 'Exploring cutting-edge technologies' },
    { icon: Target, label: 'Problem Solving', description: 'Creating efficient solutions' },
    { icon: Heart, label: 'User Experience', description: 'Designing for human connection' },
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen pt-20 pb-10 relative z-10"
    >
      <div className="max-w-6xl mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl md:text-6xl font-bold heading-glow mb-4">
            About <span className="text-neon-blue">Me</span>
          </h1>
          <p className="text-xl text-cyber-muted max-w-2xl mx-auto">
            Passionate developer crafting digital experiences that matter
          </p>
        </motion.div>

        {/* Main Content */}
        <div className="grid lg:grid-cols-2 gap-12 mb-16">
          {/* Left Column - Personal Info */}
          <motion.div
            initial={{ x: -50, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="space-y-8"
          >
            <div className="card-glow p-8 rounded-2xl">
              <div className="flex items-center space-x-4 mb-6">
                <div className="w-16 h-16 bg-gradient-to-r from-neon-blue to-neon-green rounded-full flex items-center justify-center">
                  <User className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-neon-blue">Alex Johnson</h2>
                  <p className="text-cyber-muted">Full Stack Developer</p>
                </div>
              </div>

              <div className="space-y-4 text-cyber-text">
                <div className="flex items-center space-x-3">
                  <MapPin className="w-5 h-5 text-neon-green" />
                  <span>San Francisco, CA</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Calendar className="w-5 h-5 text-neon-pink" />
                  <span>Available for opportunities</span>
                </div>
              </div>
            </div>

            {/* Bio */}
            <div className="card-glow p-8 rounded-2xl">
              <h3 className="text-xl font-bold text-neon-green mb-4">My Story</h3>
              <p className="text-cyber-muted leading-relaxed">
                I'm a passionate full-stack developer with over 5 years of experience creating 
                innovative digital solutions. My journey began with a fascination for technology 
                and has evolved into a career dedicated to building applications that solve 
                real-world problems.
              </p>
              <br />
              <p className="text-cyber-muted leading-relaxed">
                I believe in the power of clean code, user-centric design, and continuous learning. 
                When I'm not coding, you'll find me exploring new technologies, contributing to 
                open-source projects, or mentoring aspiring developers.
              </p>
            </div>
          </motion.div>

          {/* Right Column - Stats & Interests */}
          <motion.div
            initial={{ x: 50, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="space-y-8"
          >
            {/* Stats */}
            <div className="card-glow p-8 rounded-2xl">
              <h3 className="text-xl font-bold text-neon-blue mb-6">By the Numbers</h3>
              <div className="grid grid-cols-2 gap-6">
                {stats.map((stat, index) => (
                  <motion.div
                    key={index}
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 0.8 + index * 0.1 }}
                    className="text-center"
                  >
                    <div className={`text-3xl font-bold ${stat.color} mb-2`}>
                      {stat.value}
                    </div>
                    <div className="text-sm text-cyber-muted">{stat.label}</div>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Interests */}
            <div className="card-glow p-8 rounded-2xl">
              <h3 className="text-xl font-bold text-neon-pink mb-6">What Drives Me</h3>
              <div className="space-y-4">
                {interests.map((interest, index) => {
                  const Icon = interest.icon;
                  return (
                    <motion.div
                      key={index}
                      initial={{ y: 20, opacity: 0 }}
                      animate={{ y: 0, opacity: 1 }}
                      transition={{ delay: 1 + index * 0.1 }}
                      className="flex items-start space-x-4 p-4 rounded-lg hover:bg-cyber-border/20 transition-colors"
                    >
                      <Icon className="w-6 h-6 text-neon-blue mt-1" />
                      <div>
                        <h4 className="font-semibold text-cyber-text">{interest.label}</h4>
                        <p className="text-sm text-cyber-muted">{interest.description}</p>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </div>
          </motion.div>
        </div>

        {/* Quote Section */}
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 1.2 }}
          className="card-glow p-8 rounded-2xl text-center"
        >
          <blockquote className="text-xl md:text-2xl font-medium text-cyber-text mb-4">
            "The best way to predict the future is to{' '}
            <span className="text-neon-blue animate-glow">create</span> it."
          </blockquote>
          <cite className="text-cyber-muted">- My development philosophy</cite>
        </motion.div>
      </div>
    </motion.div>
  );
};

export default About;