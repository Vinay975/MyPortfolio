import React from 'react';
import { motion } from 'framer-motion';
import { TypeAnimation } from 'react-type-animation';
import { ArrowDown, Github, Linkedin, Twitter, Download, Sparkles, Code, Palette } from 'lucide-react';

const Home: React.FC = () => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen flex items-center justify-center relative z-10"
    >
      <div className="max-w-5xl mx-auto px-4 text-center">
        {/* Main Content */}
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="space-y-8"
        >
          {/* Welcome Text with enhanced styling */}
          <motion.div
            initial={{ scale: 0.9 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.3, type: "spring", stiffness: 100 }}
            className="relative"
          >
            <h1 className="text-6xl md:text-8xl font-bold heading-glow mb-6 relative">
              Hello, I'm <span className="text-neon-blue animate-glow relative">
                Alex
                <motion.div
                  className="absolute -top-2 -right-2"
                  animate={{ rotate: 360 }}
                  transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                >
                  <Sparkles className="w-8 h-8 text-neon-pink" />
                </motion.div>
              </span>
            </h1>
            
            {/* Decorative elements */}
            <div className="absolute -top-10 left-1/4 w-20 h-20 bg-neon-blue/20 rounded-full blur-xl animate-pulse" />
            <div className="absolute -bottom-10 right-1/4 w-16 h-16 bg-neon-green/20 rounded-full blur-xl animate-pulse" style={{ animationDelay: '1s' }} />
          </motion.div>

          {/* Enhanced Typing Animation */}
          <div className="text-3xl md:text-5xl font-medium text-cyber-text h-20 flex items-center justify-center">
            <div className="flex items-center space-x-4">
              <motion.div
                animate={{ rotate: [0, 360] }}
                transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
              >
                <Code className="w-8 h-8 text-neon-green" />
              </motion.div>
              <span className="text-neon-green">I am a </span>
              <span className="text-neon-blue font-bold">
                <TypeAnimation
                  sequence={[
                    'Full Stack Developer',
                    2000,
                    'Frontend Specialist',
                    2000,
                    'UI/UX Designer',
                    2000,
                    'Problem Solver',
                    2000,
                    'Tech Enthusiast',
                    2000,
                  ]}
                  wrapper="span"
                  speed={50}
                  repeat={Infinity}
                />
              </span>
              <motion.div
                animate={{ rotate: [0, -360] }}
                transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
              >
                <Palette className="w-8 h-8 text-neon-pink" />
              </motion.div>
            </div>
          </div>

          {/* Enhanced Description */}
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="relative"
          >
            <p className="text-xl md:text-2xl text-cyber-muted max-w-3xl mx-auto leading-relaxed">
              Crafting digital experiences with cutting-edge technologies and futuristic design. 
              Passionate about creating innovative solutions that push the boundaries of what's possible.
            </p>
            <div className="mt-6 flex justify-center space-x-8">
              <div className="text-center">
                <div className="text-2xl font-bold text-neon-blue">5+</div>
                <div className="text-sm text-cyber-muted">Years Experience</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-neon-green">50+</div>
                <div className="text-sm text-cyber-muted">Projects Completed</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-neon-pink">30+</div>
                <div className="text-sm text-cyber-muted">Happy Clients</div>
              </div>
            </div>
          </motion.div>

          {/* Enhanced CTA Buttons */}
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.7 }}
            className="flex flex-col sm:flex-row gap-6 justify-center items-center"
          >
            <motion.button 
              className="neon-btn group relative"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <span className="flex items-center space-x-3">
                <span>View My Work</span>
                <ArrowDown className="w-5 h-5 group-hover:animate-bounce" />
              </span>
            </motion.button>
            
            <motion.button 
              className="neon-btn border-neon-green text-neon-green hover:bg-neon-green group relative"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <span className="flex items-center space-x-3">
                <Download className="w-5 h-5" />
                <span>Download CV</span>
              </span>
            </motion.button>
          </motion.div>

          {/* Enhanced Social Links */}
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.9 }}
            className="flex justify-center space-x-8 pt-8"
          >
            {[
              { icon: Github, color: 'text-neon-blue hover:text-neon-blue', href: '#', bg: 'hover:bg-neon-blue/10' },
              { icon: Linkedin, color: 'text-neon-green hover:text-neon-green', href: '#', bg: 'hover:bg-neon-green/10' },
              { icon: Twitter, color: 'text-neon-pink hover:text-neon-pink', href: '#', bg: 'hover:bg-neon-pink/10' },
            ].map((social, index) => {
              const Icon = social.icon;
              return (
                <motion.a
                  key={index}
                  href={social.href}
                  whileHover={{ scale: 1.3, rotate: 5 }}
                  whileTap={{ scale: 0.9 }}
                  className={`${social.color} ${social.bg} p-3 rounded-full transition-all duration-300 border border-transparent hover:border-current`}
                >
                  <Icon size={32} />
                </motion.a>
              );
            })}
          </motion.div>
        </motion.div>

        {/* Enhanced Floating Elements */}
        <motion.div
          className="absolute top-20 left-10 w-24 h-24 bg-gradient-to-r from-neon-blue/20 to-neon-green/20 rounded-full"
          animate={{ 
            y: [0, -20, 0],
            rotate: [0, 180, 360],
            scale: [1, 1.1, 1]
          }}
          transition={{ 
            duration: 6, 
            repeat: Infinity, 
            ease: "easeInOut" 
          }}
        />
        <motion.div
          className="absolute bottom-20 right-10 w-20 h-20 bg-gradient-to-r from-neon-pink/20 to-neon-purple/20 rounded-full"
          animate={{ 
            y: [0, 20, 0],
            rotate: [360, 180, 0],
            scale: [1, 0.9, 1]
          }}
          transition={{ 
            duration: 8, 
            repeat: Infinity, 
            ease: "easeInOut",
            delay: 2
          }}
        />
        <motion.div
          className="absolute top-1/2 left-5 w-16 h-16 bg-gradient-to-r from-neon-yellow/20 to-neon-orange/20 rounded-full"
          animate={{ 
            x: [0, 15, 0],
            y: [0, -15, 0],
            rotate: [0, 90, 180, 270, 360]
          }}
          transition={{ 
            duration: 10, 
            repeat: Infinity, 
            ease: "easeInOut",
            delay: 4
          }}
        />

        {/* Enhanced Scroll Indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2 }}
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
        >
          <motion.div 
            className="flex flex-col items-center space-y-3 text-cyber-muted"
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <span className="text-sm font-medium">Scroll to explore</span>
            <div className="w-6 h-10 border-2 border-neon-blue/50 rounded-full flex justify-center">
              <motion.div
                className="w-1 h-3 bg-neon-blue rounded-full mt-2"
                animate={{ y: [0, 12, 0] }}
                transition={{ duration: 1.5, repeat: Infinity }}
              />
            </div>
          </motion.div>
        </motion.div>
      </div>
    </motion.div>
  );
};

export default Home;