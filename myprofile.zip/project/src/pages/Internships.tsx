import React from 'react';
import { motion } from 'framer-motion';
import { Building, Calendar, MapPin, Briefcase, CheckCircle, TrendingUp } from 'lucide-react';

const Internships: React.FC = () => {
  const internships = [
    {
      title: 'Senior Software Engineering Intern',
      company: 'Google',
      location: 'Mountain View, CA',
      period: 'Summer 2020',
      duration: '3 months',
      type: 'Full-time',
      description: 'Worked on improving the performance of Google Search algorithms and implemented new features for the search interface.',
      responsibilities: [
        'Developed and optimized search algorithms using Python and C++',
        'Collaborated with senior engineers on performance improvements',
        'Built internal tools for monitoring search performance metrics',
        'Participated in code reviews and technical design discussions',
      ],
      technologies: ['Python', 'C++', 'TensorFlow', 'Kubernetes', 'Go'],
      achievements: [
        'Improved search query processing speed by 15%',
        'Mentored 2 junior interns',
        'Presented project to VP of Engineering',
      ],
      color: 'neon-blue',
      logo: '🌐',
    },
    {
      title: 'Full Stack Developer Intern',
      company: 'Meta (Facebook)',
      location: 'Menlo Park, CA',
      period: 'Summer 2019',
      duration: '3 months',
      type: 'Full-time',
      description: 'Contributed to the development of Facebook\'s internal tools and worked on improving user engagement features.',
      responsibilities: [
        'Built React components for internal dashboard applications',
        'Developed RESTful APIs using Node.js and GraphQL',
        'Implemented real-time features using WebSocket connections',
        'Optimized database queries and improved API response times',
      ],
      technologies: ['React', 'Node.js', 'GraphQL', 'MySQL', 'Redis'],
      achievements: [
        'Reduced API response time by 30%',
        'Launched 3 new dashboard features',
        'Received outstanding intern performance rating',
      ],
      color: 'neon-green',
      logo: '📘',
    },
    {
      title: 'Frontend Developer Intern',
      company: 'Stripe',
      location: 'San Francisco, CA',
      period: 'Summer 2018',
      duration: '3 months',
      type: 'Full-time',
      description: 'Focused on improving the Stripe Dashboard user experience and implementing new payment flow features.',
      responsibilities: [
        'Enhanced UI/UX of the Stripe Dashboard using React',
        'Implemented responsive design for mobile compatibility',
        'Worked on A/B testing framework for new features',
        'Collaborated with design team on user interface improvements',
      ],
      technologies: ['React', 'TypeScript', 'SCSS', 'Webpack', 'Jest'],
      achievements: [
        'Increased user engagement by 20%',
        'Implemented 5+ new dashboard features',
        'Contributed to open-source Stripe SDK',
      ],
      color: 'neon-pink',
      logo: '💳',
    },
    {
      title: 'Backend Developer Intern',
      company: 'Airbnb',
      location: 'San Francisco, CA',
      period: 'Summer 2017',
      duration: '3 months',
      type: 'Full-time',
      description: 'Worked on the backend infrastructure for Airbnb\'s booking system and payment processing.',
      responsibilities: [
        'Developed microservices for the booking platform using Ruby',
        'Implemented caching strategies to improve performance',
        'Built monitoring and alerting systems for production services',
        'Participated in on-call rotation for critical services',
      ],
      technologies: ['Ruby on Rails', 'PostgreSQL', 'Redis', 'AWS', 'Docker'],
      achievements: [
        'Reduced booking processing time by 25%',
        'Implemented robust error handling system',
        'Improved system reliability to 99.9% uptime',
      ],
      color: 'neon-purple',
      logo: '🏠',
    },
  ];

  const skills = [
    'Technical Leadership',
    'Cross-functional Collaboration',
    'Agile Development',
    'Code Review',
    'System Design',
    'Performance Optimization',
    'Mentoring',
    'Project Management',
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen pt-20 pb-10 relative z-10"
    >
      <div className="max-w-6xl mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl md:text-6xl font-bold heading-glow mb-4">
            My <span className="text-neon-blue">Experience</span>
          </h1>
          <p className="text-xl text-cyber-muted max-w-2xl mx-auto">
            Professional journey through top-tier technology companies
          </p>
        </motion.div>

        {/* Experience Timeline */}
        <div className="space-y-12 mb-16">
          {internships.map((internship, index) => (
            <motion.div
              key={index}
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.4 + index * 0.2 }}
              className="relative"
            >
              {/* Timeline Line */}
              {index < internships.length - 1 && (
                <div className="absolute left-8 top-20 w-0.5 h-32 bg-gradient-to-b from-neon-blue to-neon-green opacity-30" />
              )}
              
              <div className="card-glow p-8 rounded-2xl ml-16 relative">
                {/* Company Logo/Icon */}
                <div className={`absolute -left-12 top-8 w-16 h-16 bg-${internship.color}/10 border-2 border-${internship.color}/30 rounded-full flex items-center justify-center text-2xl`}>
                  {internship.logo}
                </div>

                {/* Header */}
                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-6">
                  <div>
                    <h3 className={`text-2xl font-bold text-${internship.color} mb-2`}>
                      {internship.title}
                    </h3>
                    <div className="flex flex-col sm:flex-row sm:items-center gap-4 text-cyber-muted">
                      <div className="flex items-center space-x-2">
                        <Building className="w-4 h-4" />
                        <span className="font-semibold">{internship.company}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <MapPin className="w-4 h-4" />
                        <span>{internship.location}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Calendar className="w-4 h-4" />
                        <span>{internship.period}</span>
                      </div>
                    </div>
                  </div>
                  <div className="mt-4 lg:mt-0 flex gap-2">
                    <span className={`px-3 py-1 text-xs bg-${internship.color}/10 border border-${internship.color}/30 text-${internship.color} rounded-full`}>
                      {internship.duration}
                    </span>
                    <span className="px-3 py-1 text-xs bg-cyber-border text-cyber-text rounded-full">
                      {internship.type}
                    </span>
                  </div>
                </div>

                <p className="text-cyber-text mb-6">{internship.description}</p>

                {/* Responsibilities */}
                <div className="mb-6">
                  <h4 className="font-semibold text-cyber-text mb-3 flex items-center">
                    <Briefcase className="w-4 h-4 mr-2 text-neon-blue" />
                    Key Responsibilities
                  </h4>
                  <ul className="space-y-2">
                    {internship.responsibilities.map((responsibility, respIndex) => (
                      <li
                        key={respIndex}
                        className="flex items-start space-x-2 text-cyber-muted"
                      >
                        <CheckCircle className="w-4 h-4 text-neon-green mt-0.5 flex-shrink-0" />
                        <span className="text-sm">{responsibility}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Technologies */}
                <div className="mb-6">
                  <h4 className="font-semibold text-cyber-text mb-3">Technologies Used</h4>
                  <div className="flex flex-wrap gap-2">
                    {internship.technologies.map((tech, techIndex) => (
                      <span
                        key={techIndex}
                        className="px-3 py-1 text-sm bg-cyber-border text-cyber-text rounded-full"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Achievements */}
                <div>
                  <h4 className="font-semibold text-cyber-text mb-3 flex items-center">
                    <TrendingUp className="w-4 h-4 mr-2 text-neon-green" />
                    Key Achievements
                  </h4>
                  <ul className="space-y-2">
                    {internship.achievements.map((achievement, achIndex) => (
                      <li
                        key={achIndex}
                        className="flex items-start space-x-2 text-cyber-muted"
                      >
                        <div className={`w-2 h-2 bg-${internship.color} rounded-full mt-2 flex-shrink-0`} />
                        <span className="text-sm">{achievement}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Skills Gained */}
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 1.2 }}
          className="mb-16"
        >
          <h2 className="text-2xl font-bold text-neon-green mb-8 text-center">
            Professional Skills Developed
          </h2>
          <div className="card-glow p-8 rounded-2xl">
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
              {skills.map((skill, index) => (
                <motion.div
                  key={index}
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 1.4 + index * 0.1 }}
                  className="flex items-center space-x-3 p-4 rounded-lg bg-cyber-border/20 border border-neon-blue/30 hover:border-neon-blue/60 transition-colors"
                >
                  <CheckCircle className="w-5 h-5 text-neon-green" />
                  <span className="text-cyber-text font-medium">{skill}</span>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Summary */}
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 1.8 }}
          className="card-glow p-8 rounded-2xl text-center"
        >
          <h3 className="text-2xl font-bold text-neon-blue mb-4">Experience Summary</h3>
          <p className="text-cyber-text text-lg mb-6">
            Through internships at leading technology companies, I've gained invaluable experience 
            in building scalable systems, working with diverse teams, and delivering impactful solutions.
          </p>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-neon-blue mb-2">4</div>
              <div className="text-cyber-muted">Major Companies</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-neon-green mb-2">12</div>
              <div className="text-cyber-muted">Months of Experience</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-neon-pink mb-2">20+</div>
              <div className="text-cyber-muted">Projects Delivered</div>
            </div>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
};

export default Internships;