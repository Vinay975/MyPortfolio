import React from 'react';
import { motion } from 'framer-motion';
import { GraduationCap, Calendar, MapPin, Award, Book, Star } from 'lucide-react';

const Education: React.FC = () => {
  const education = [
    {
      degree: 'Master of Computer Science',
      school: 'Stanford University',
      location: 'Stanford, CA',
      period: '2019 - 2021',
      gpa: '3.9/4.0',
      description: 'Specialized in Artificial Intelligence and Machine Learning with focus on web technologies.',
      courses: ['Advanced Algorithms', 'Machine Learning', 'Database Systems', 'Human-Computer Interaction'],
      achievements: ['Dean\'s List', 'Research Assistant', 'Graduate Teaching Assistant'],
      color: 'neon-blue',
    },
    {
      degree: 'Bachelor of Software Engineering',
      school: 'University of California, Berkeley',
      location: 'Berkeley, CA',
      period: '2015 - 2019',
      gpa: '3.8/4.0',
      description: 'Comprehensive software engineering program with emphasis on full-stack development.',
      courses: ['Data Structures', 'Software Architecture', 'Web Development', 'Mobile App Development'],
      achievements: ['Summa Cum Laude', 'Programming Competition Winner', 'Student Government VP'],
      color: 'neon-green',
    },
  ];

  const certifications = [
    {
      title: 'AWS Certified Solutions Architect',
      issuer: 'Amazon Web Services',
      date: '2023',
      validUntil: '2026',
      icon: '☁️',
      color: 'neon-blue',
    },
    {
      title: 'Google Cloud Professional Developer',
      issuer: 'Google Cloud',
      date: '2022',
      validUntil: '2025',
      icon: '🌐',
      color: 'neon-green',
    },
    {
      title: 'Certified Kubernetes Administrator',
      issuer: 'Cloud Native Computing Foundation',
      date: '2023',
      validUntil: '2026',
      icon: '⚙️',
      color: 'neon-pink',
    },
    {
      title: 'React Advanced Certification',
      issuer: 'Meta',
      date: '2022',
      validUntil: 'Lifetime',
      icon: '⚛️',
      color: 'neon-purple',
    },
  ];

  const onlineCourses = [
    {
      title: 'Full Stack Web Development',
      platform: 'freeCodeCamp',
      completed: '2021',
      hours: '300+',
    },
    {
      title: 'Advanced React Patterns',
      platform: 'Epic React',
      completed: '2022',
      hours: '40',
    },
    {
      title: 'System Design Interview',
      platform: 'Educative',
      completed: '2023',
      hours: '60',
    },
    {
      title: 'Docker & Kubernetes',
      platform: 'Udemy',
      completed: '2023',
      hours: '50',
    },
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen pt-20 pb-10 relative z-10"
    >
      <div className="max-w-6xl mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl md:text-6xl font-bold heading-glow mb-4">
            My <span className="text-neon-blue">Education</span>
          </h1>
          <p className="text-xl text-cyber-muted max-w-2xl mx-auto">
            Continuous learning journey through formal education and professional development
          </p>
        </motion.div>

        {/* Formal Education */}
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="mb-16"
        >
          <h2 className="text-2xl font-bold text-neon-green mb-8 flex items-center">
            <GraduationCap className="w-6 h-6 mr-2" />
            Formal Education
          </h2>
          
          <div className="space-y-8">
            {education.map((edu, index) => (
              <motion.div
                key={index}
                initial={{ x: index % 2 === 0 ? -50 : 50, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: 0.6 + index * 0.2 }}
                className="card-glow p-8 rounded-2xl"
              >
                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-6">
                  <div>
                    <h3 className={`text-2xl font-bold text-${edu.color} mb-2`}>
                      {edu.degree}
                    </h3>
                    <div className="flex flex-col sm:flex-row sm:items-center gap-4 text-cyber-muted">
                      <div className="flex items-center space-x-2">
                        <Book className="w-4 h-4" />
                        <span>{edu.school}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <MapPin className="w-4 h-4" />
                        <span>{edu.location}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Calendar className="w-4 h-4" />
                        <span>{edu.period}</span>
                      </div>
                    </div>
                  </div>
                  <div className="mt-4 lg:mt-0">
                    <div className={`px-4 py-2 bg-${edu.color}/10 border border-${edu.color}/30 rounded-lg`}>
                      <span className={`font-semibold text-${edu.color}`}>GPA: {edu.gpa}</span>
                    </div>
                  </div>
                </div>

                <p className="text-cyber-text mb-6">{edu.description}</p>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold text-cyber-text mb-3 flex items-center">
                      <Book className="w-4 h-4 mr-2 text-neon-blue" />
                      Key Courses
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {edu.courses.map((course, courseIndex) => (
                        <span
                          key={courseIndex}
                          className="px-3 py-1 text-sm bg-cyber-border text-cyber-text rounded-full"
                        >
                          {course}
                        </span>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold text-cyber-text mb-3 flex items-center">
                      <Award className="w-4 h-4 mr-2 text-neon-green" />
                      Achievements
                    </h4>
                    <ul className="space-y-1">
                      {edu.achievements.map((achievement, achIndex) => (
                        <li
                          key={achIndex}
                          className="flex items-center space-x-2 text-cyber-muted"
                        >
                          <Star className="w-3 h-3 text-neon-yellow" />
                          <span className="text-sm">{achievement}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Certifications */}
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 1 }}
          className="mb-16"
        >
          <h2 className="text-2xl font-bold text-neon-pink mb-8 flex items-center">
            <Award className="w-6 h-6 mr-2" />
            Professional Certifications
          </h2>
          
          <div className="grid md:grid-cols-2 gap-6">
            {certifications.map((cert, index) => (
              <motion.div
                key={index}
                initial={{ y: 30, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 1.2 + index * 0.1 }}
                className="card-glow p-6 rounded-2xl"
              >
                <div className="flex items-start space-x-4">
                  <div className="text-3xl">{cert.icon}</div>
                  <div className="flex-1">
                    <h3 className={`font-bold text-${cert.color} mb-2`}>
                      {cert.title}
                    </h3>
                    <p className="text-cyber-muted text-sm mb-3">{cert.issuer}</p>
                    <div className="flex justify-between items-center text-xs text-cyber-muted">
                      <span>Earned: {cert.date}</span>
                      <span>Valid Until: {cert.validUntil}</span>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Online Learning */}
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 1.6 }}
          className="mb-16"
        >
          <h2 className="text-2xl font-bold text-neon-purple mb-8 flex items-center">
            <Book className="w-6 h-6 mr-2" />
            Continuous Learning
          </h2>
          
          <div className="grid md:grid-cols-2 gap-6">
            {onlineCourses.map((course, index) => (
              <motion.div
                key={index}
                initial={{ x: index % 2 === 0 ? -30 : 30, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: 1.8 + index * 0.1 }}
                className="card-glow p-6 rounded-2xl"
              >
                <div className="flex justify-between items-start mb-4">
                  <h3 className="font-bold text-cyber-text">{course.title}</h3>
                  <span className="text-xs text-cyber-muted bg-cyber-border px-2 py-1 rounded">
                    {course.hours} hours
                  </span>
                </div>
                <div className="flex justify-between items-center text-sm text-cyber-muted">
                  <span>{course.platform}</span>
                  <span>Completed: {course.completed}</span>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Learning Philosophy */}
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 2.2 }}
          className="card-glow p-8 rounded-2xl text-center"
        >
          <h3 className="text-2xl font-bold text-neon-blue mb-4">Learning Philosophy</h3>
          <blockquote className="text-lg text-cyber-text mb-4">
            "Education is not preparation for life; education{' '}
            <span className="text-neon-green animate-glow">is</span> life itself."
          </blockquote>
          <p className="text-cyber-muted">
            I believe in continuous learning and staying updated with the latest technologies 
            and best practices in software development.
          </p>
        </motion.div>
      </div>
    </motion.div>
  );
};

export default Education;