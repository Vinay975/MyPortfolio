import React from 'react';
import { motion } from 'framer-motion';
import { Code, Database, Smartphone, Palette, Server, Globe } from 'lucide-react';

const Skills: React.FC = () => {
  const skillCategories = [
    {
      icon: Code,
      title: 'Frontend Development',
      color: 'text-neon-blue',
      bgColor: 'bg-neon-blue/10',
      skills: [
        { name: 'React', level: 95 },
        { name: 'TypeScript', level: 90 },
        { name: 'Next.js', level: 85 },
        { name: 'Vue.js', level: 80 },
        { name: 'Tailwind CSS', level: 95 },
        { name: 'Framer Motion', level: 85 },
      ],
    },
    {
      icon: Server,
      title: 'Backend Development',
      color: 'text-neon-green',
      bgColor: 'bg-neon-green/10',
      skills: [
        { name: 'Node.js', level: 90 },
        { name: 'Python', level: 85 },
        { name: 'Express.js', level: 88 },
        { name: 'GraphQL', level: 75 },
        { name: 'REST APIs', level: 92 },
        { name: 'Microservices', level: 80 },
      ],
    },
    {
      icon: Database,
      title: 'Database & Cloud',
      color: 'text-neon-pink',
      bgColor: 'bg-neon-pink/10',
      skills: [
        { name: 'PostgreSQL', level: 85 },
        { name: 'MongoDB', level: 88 },
        { name: 'Redis', level: 75 },
        { name: 'AWS', level: 80 },
        { name: 'Docker', level: 85 },
        { name: 'Kubernetes', level: 70 },
      ],
    },
    {
      icon: Smartphone,
      title: 'Mobile Development',
      color: 'text-neon-purple',
      bgColor: 'bg-neon-purple/10',
      skills: [
        { name: 'React Native', level: 85 },
        { name: 'Flutter', level: 75 },
        { name: 'iOS (Swift)', level: 70 },
        { name: 'Android (Kotlin)', level: 72 },
        { name: 'Expo', level: 88 },
        { name: 'Firebase', level: 85 },
      ],
    },
    {
      icon: Palette,
      title: 'UI/UX Design',
      color: 'text-neon-yellow',
      bgColor: 'bg-neon-yellow/10',
      skills: [
        { name: 'Figma', level: 90 },
        { name: 'Adobe XD', level: 85 },
        { name: 'Sketch', level: 80 },
        { name: 'Prototyping', level: 88 },
        { name: 'User Research', level: 75 },
        { name: 'Design Systems', level: 85 },
      ],
    },
    {
      icon: Globe,
      title: 'DevOps & Tools',
      color: 'text-neon-orange',
      bgColor: 'bg-neon-orange/10',
      skills: [
        { name: 'Git/GitHub', level: 95 },
        { name: 'CI/CD', level: 85 },
        { name: 'Linux', level: 80 },
        { name: 'Nginx', level: 75 },
        { name: 'Webpack', level: 85 },
        { name: 'Testing (Jest)', level: 88 },
      ],
    },
  ];

  const certifications = [
    'AWS Certified Developer',
    'Google Cloud Professional',
    'React Advanced Certification',
    'Node.js Expert Certification',
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen pt-20 pb-10 relative z-10"
    >
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl md:text-6xl font-bold heading-glow mb-4">
            My <span className="text-neon-blue">Skills</span>
          </h1>
          <p className="text-xl text-cyber-muted max-w-2xl mx-auto">
            A comprehensive toolkit for building exceptional digital experiences
          </p>
        </motion.div>

        {/* Skills Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {skillCategories.map((category, index) => {
            const Icon = category.icon;
            return (
              <motion.div
                key={index}
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.4 + index * 0.1 }}
                className="card-glow p-6 rounded-2xl"
              >
                <div className="flex items-center space-x-4 mb-6">
                  <div className={`w-12 h-12 ${category.bgColor} rounded-xl flex items-center justify-center`}>
                    <Icon className={`w-6 h-6 ${category.color}`} />
                  </div>
                  <h3 className={`text-lg font-bold ${category.color}`}>
                    {category.title}
                  </h3>
                </div>

                <div className="space-y-4">
                  {category.skills.map((skill, skillIndex) => (
                    <motion.div
                      key={skillIndex}
                      initial={{ width: 0 }}
                      animate={{ width: '100%' }}
                      transition={{ delay: 0.8 + index * 0.1 + skillIndex * 0.05 }}
                      className="space-y-2"
                    >
                      <div className="flex justify-between items-center">
                        <span className="text-cyber-text font-medium">{skill.name}</span>
                        <span className={`text-sm ${category.color} font-semibold`}>
                          {skill.level}%
                        </span>
                      </div>
                      <div className="w-full bg-cyber-border rounded-full h-2">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: `${skill.level}%` }}
                          transition={{ 
                            delay: 1 + index * 0.1 + skillIndex * 0.05,
                            duration: 0.8,
                            ease: "easeOut"
                          }}
                          className={`h-2 rounded-full bg-gradient-to-r ${
                            category.color === 'text-neon-blue' ? 'from-neon-blue to-neon-blue/60' :
                            category.color === 'text-neon-green' ? 'from-neon-green to-neon-green/60' :
                            category.color === 'text-neon-pink' ? 'from-neon-pink to-neon-pink/60' :
                            category.color === 'text-neon-purple' ? 'from-neon-purple to-neon-purple/60' :
                            category.color === 'text-neon-yellow' ? 'from-neon-yellow to-neon-yellow/60' :
                            'from-neon-orange to-neon-orange/60'
                          }`}
                          style={{
                            boxShadow: `0 0 10px ${
                              category.color === 'text-neon-blue' ? '#00f5ff' :
                              category.color === 'text-neon-green' ? '#39ff14' :
                              category.color === 'text-neon-pink' ? '#ff10f0' :
                              category.color === 'text-neon-purple' ? '#bf00ff' :
                              category.color === 'text-neon-yellow' ? '#ffff00' :
                              '#ff8c00'
                            }30`
                          }}
                        />
                      </div>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Certifications */}
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 1.2 }}
          className="card-glow p-8 rounded-2xl mb-16"
        >
          <h2 className="text-2xl font-bold text-neon-green mb-6 text-center">
            Certifications & Achievements
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            {certifications.map((cert, index) => (
              <motion.div
                key={index}
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 1.4 + index * 0.1 }}
                className="bg-cyber-border/20 p-4 rounded-xl text-center border border-neon-blue/30 hover:border-neon-blue/60 transition-colors"
              >
                <span className="text-cyber-text font-medium">{cert}</span>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Tech Stack Summary */}
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 1.6 }}
          className="text-center"
        >
          <div className="card-glow p-8 rounded-2xl">
            <h3 className="text-2xl font-bold text-neon-blue mb-4">Current Tech Stack</h3>
            <p className="text-cyber-muted mb-6">
              Technologies I'm currently working with and passionate about
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              {[
                'React', 'TypeScript', 'Node.js', 'Python', 'PostgreSQL', 
                'AWS', 'Docker', 'Next.js', 'Tailwind CSS', 'GraphQL'
              ].map((tech, index) => (
                <motion.span
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 1.8 + index * 0.05 }}
                  className="px-4 py-2 bg-gradient-to-r from-neon-blue/20 to-neon-green/20 text-cyber-text rounded-full border border-neon-blue/30 hover:border-neon-blue/60 transition-colors"
                >
                  {tech}
                </motion.span>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
};

export default Skills;