import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, Phone, MapPin, Send, Github, Linkedin, Twitter, MessageSquare } from 'lucide-react';

const Contact: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setIsSubmitting(false);
    setFormData({ name: '', email: '', subject: '', message: '' });
    alert('Message sent successfully!');
  };

  const contactInfo = [
    {
      icon: Mail,
      label: 'Email',
      value: 'alex@example.com',
      href: 'mailto:alex@example.com',
      color: 'text-neon-blue',
      bgColor: 'bg-neon-blue/10',
    },
    {
      icon: Phone,
      label: 'Phone',
      value: '+1 (555) 123-4567',
      href: 'tel:+15551234567',
      color: 'text-neon-green',
      bgColor: 'bg-neon-green/10',
    },
    {
      icon: MapPin,
      label: 'Location',
      value: 'San Francisco, CA',
      href: '#',
      color: 'text-neon-pink',
      bgColor: 'bg-neon-pink/10',
    },
  ];

  const socialLinks = [
    {
      icon: Github,
      label: 'GitHub',
      href: 'https://github.com',
      color: 'text-neon-blue',
      hoverColor: 'hover:text-neon-blue',
    },
    {
      icon: Linkedin,
      label: 'LinkedIn',
      href: 'https://linkedin.com',
      color: 'text-neon-green',
      hoverColor: 'hover:text-neon-green',
    },
    {
      icon: Twitter,
      label: 'Twitter',
      href: 'https://twitter.com',
      color: 'text-neon-pink',
      hoverColor: 'hover:text-neon-pink',
    },
    {
      icon: MessageSquare,
      label: 'Discord',
      href: '#',
      color: 'text-neon-purple',
      hoverColor: 'hover:text-neon-purple',
    },
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen pt-20 pb-10 relative z-10"
    >
      <div className="max-w-6xl mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl md:text-6xl font-bold heading-glow mb-4">
            Get In <span className="text-neon-blue">Touch</span>
          </h1>
          <p className="text-xl text-cyber-muted max-w-2xl mx-auto">
            Let's discuss your next project and bring your ideas to life
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <motion.div
            initial={{ x: -50, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="card-glow p-8 rounded-2xl"
          >
            <h2 className="text-2xl font-bold text-neon-green mb-6 flex items-center">
              <Send className="w-6 h-6 mr-2" />
              Send Message
            </h2>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-cyber-text mb-2">
                    Name
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 bg-cyber-border/20 border border-cyber-border rounded-lg text-cyber-text placeholder-cyber-muted focus:border-neon-blue focus:outline-none transition-colors"
                    placeholder="Your Name"
                  />
                </div>

                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-cyber-text mb-2">
                    Email
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 bg-cyber-border/20 border border-cyber-border rounded-lg text-cyber-text placeholder-cyber-muted focus:border-neon-blue focus:outline-none transition-colors"
                    placeholder="your@email.com"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="subject" className="block text-sm font-medium text-cyber-text mb-2">
                  Subject
                </label>
                <input
                  type="text"
                  id="subject"
                  name="subject"
                  value={formData.subject}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 bg-cyber-border/20 border border-cyber-border rounded-lg text-cyber-text placeholder-cyber-muted focus:border-neon-blue focus:outline-none transition-colors"
                  placeholder="Project Discussion"
                />
              </div>

              <div>
                <label htmlFor="message" className="block text-sm font-medium text-cyber-text mb-2">
                  Message
                </label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  required
                  rows={6}
                  className="w-full px-4 py-3 bg-cyber-border/20 border border-cyber-border rounded-lg text-cyber-text placeholder-cyber-muted focus:border-neon-blue focus:outline-none transition-colors resize-none"
                  placeholder="Tell me about your project..."
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className={`w-full neon-btn ${isSubmitting ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                <span className="flex items-center justify-center space-x-2">
                  <Send className="w-4 h-4" />
                  <span>{isSubmitting ? 'Sending...' : 'Send Message'}</span>
                </span>
              </button>
            </form>
          </motion.div>

          {/* Contact Info & Social */}
          <motion.div
            initial={{ x: 50, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="space-y-8"
          >
            {/* Contact Information */}
            <div className="card-glow p-8 rounded-2xl">
              <h2 className="text-2xl font-bold text-neon-blue mb-6">Contact Information</h2>
              <div className="space-y-6">
                {contactInfo.map((info, index) => {
                  const Icon = info.icon;
                  return (
                    <motion.a
                      key={index}
                      href={info.href}
                      initial={{ y: 20, opacity: 0 }}
                      animate={{ y: 0, opacity: 1 }}
                      transition={{ delay: 0.8 + index * 0.1 }}
                      className="flex items-center space-x-4 p-4 rounded-lg hover:bg-cyber-border/20 transition-colors group"
                    >
                      <div className={`w-12 h-12 ${info.bgColor} rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform`}>
                        <Icon className={`w-6 h-6 ${info.color}`} />
                      </div>
                      <div>
                        <div className="text-cyber-muted text-sm">{info.label}</div>
                        <div className="text-cyber-text font-medium">{info.value}</div>
                      </div>
                    </motion.a>
                  );
                })}
              </div>
            </div>

            {/* Social Links */}
            <div className="card-glow p-8 rounded-2xl">
              <h2 className="text-2xl font-bold text-neon-pink mb-6">Follow Me</h2>
              <div className="grid grid-cols-2 gap-4">
                {socialLinks.map((social, index) => {
                  const Icon = social.icon;
                  return (
                    <motion.a
                      key={index}
                      href={social.href}
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ delay: 1.2 + index * 0.1 }}
                      className={`flex items-center space-x-3 p-4 rounded-lg bg-cyber-border/20 border border-cyber-border ${social.hoverColor} hover:border-current transition-all group`}
                    >
                      <Icon className="w-5 h-5 group-hover:scale-110 transition-transform" />
                      <span className="font-medium">{social.label}</span>
                    </motion.a>
                  );
                })}
              </div>
            </div>

            {/* Availability */}
            <motion.div
              initial={{ y: 30, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 1.6 }}
              className="card-glow p-8 rounded-2xl text-center"
            >
              <div className="w-16 h-16 bg-neon-green/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <div className="w-3 h-3 bg-neon-green rounded-full animate-pulse" />
              </div>
              <h3 className="text-xl font-bold text-neon-green mb-2">Available for Work</h3>
              <p className="text-cyber-muted">
                Currently accepting new projects and collaborations
              </p>
            </motion.div>
          </motion.div>
        </div>

        {/* FAQ Section */}
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 1.8 }}
          className="mt-16 card-glow p-8 rounded-2xl"
        >
          <h2 className="text-2xl font-bold text-neon-purple mb-6 text-center">Frequently Asked Questions</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h3 className="font-bold text-cyber-text mb-2">What's your typical response time?</h3>
              <p className="text-cyber-muted text-sm">I usually respond within 24 hours during business days.</p>
            </div>
            <div>
              <h3 className="font-bold text-cyber-text mb-2">Do you work on weekends?</h3>
              <p className="text-cyber-muted text-sm">I'm available for urgent projects, but prefer to discuss this beforehand.</p>
            </div>
            <div>
              <h3 className="font-bold text-cyber-text mb-2">What's your hourly rate?</h3>
              <p className="text-cyber-muted text-sm">Rates vary based on project complexity. Let's discuss your specific needs.</p>
            </div>
            <div>
              <h3 className="font-bold text-cyber-text mb-2">Do you offer maintenance services?</h3>
              <p className="text-cyber-muted text-sm">Yes, I provide ongoing support and maintenance for projects I develop.</p>
            </div>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
};

export default Contact;